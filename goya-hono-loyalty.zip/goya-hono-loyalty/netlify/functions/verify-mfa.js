/**
 * verify-mfa.js
 * Verifica o código MFA enviado por send-mfa.js
 *
 * Compartilha o codeStore via módulo — funciona dentro da mesma
 * instância da função Netlify. Para persistência entre instâncias,
 * migrar para Netlify Blobs ou Redis.
 */

// Importa o mesmo store do send-mfa para compartilhar códigos
// (Netlify reutiliza o mesmo processo Node para funções na mesma invocação)
let codeStore;
try {
  codeStore = require('./send-mfa').codeStore ||
    (global.__mfaStore = global.__mfaStore || {});
} catch {
  codeStore = (global.__mfaStore = global.__mfaStore || {});
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  let email, code;
  try {
    ({ email, code } = JSON.parse(event.body || '{}'));
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid body' }) };
  }

  if (!email || !code) {
    return {
      statusCode: 400,
      body: JSON.stringify({ ok: false, message: 'Dados incompletos.' })
    };
  }

  const entry = codeStore[email];

  if (!entry) {
    return {
      statusCode: 400,
      body: JSON.stringify({ ok: false, message: 'Código não encontrado. Solicite um novo.' })
    };
  }

  if (Date.now() > entry.expiresAt) {
    delete codeStore[email];
    return {
      statusCode: 400,
      body: JSON.stringify({ ok: false, message: 'Código expirado. Solicite um novo.' })
    };
  }

  if (entry.code !== String(code).trim()) {
    return {
      statusCode: 400,
      body: JSON.stringify({ ok: false, message: 'Código incorreto. Tente novamente.' })
    };
  }

  // Código válido — invalidar após uso
  delete codeStore[email];

  return {
    statusCode: 200,
    body: JSON.stringify({ ok: true })
  };
};
